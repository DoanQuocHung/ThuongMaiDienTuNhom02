import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { TaiKhoan } from '../models/tai-khoan.model';
import { QltaikhoanService } from '../qlcomponent/shared/qltaikhoan.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  readonly baseURL = 'https://localhost:5001/api/taikhoans/';


  constructor( ) { }
   
  
}