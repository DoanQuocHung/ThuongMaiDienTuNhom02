import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ChiTietDonHang } from '../models/ChiTietDonHang';

@Injectable({
  providedIn: 'root'
})
export class ChitietdonhangService {
  url = environment.apiUrl;

  constructor(

    private http: HttpClient
  ) { }

  themChiTietDonHang(ctdh: ChiTietDonHang) {
    return this.http.post(this.url + "chitietdonhangs", ctdh);
  }

}
