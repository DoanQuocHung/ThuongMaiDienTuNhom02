import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Qlsanpham } from '../qlcomponent/shared/qlsanpham.model';

@Injectable({
  providedIn: 'root'
})
export class SanphamService {

  sanphams: Qlsanpham[];
  url = environment.apiUrl;

  constructor(private http: HttpClient) { }

  getProducts(): any {
    return this.http.get<Qlsanpham[]>(this.url + 'sanphams');
  }

  getProduct(id: any): any {
    return this.http.get<Qlsanpham>(this.url + 'sanphams/' + id);
  }

  capNhatSanPham(sanPham: Qlsanpham) {
    return this.http.put(this.url + 'sanphams', sanPham);
  }

  laySanPhamTheoGioiTinh(luachon: String) {
    return this.http.get<Qlsanpham[]>(this.url + 'sanphams/luachons/' + luachon);
  }
}
