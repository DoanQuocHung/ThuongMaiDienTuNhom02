import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { GioHang } from '../models/gio-hang.model';

@Injectable({
  providedIn: 'root'
})
export class GiohangService {

  url = environment.apiUrl;
  private items: any;
  private itemsHienHanh: any;
  // private _cart: Cart;

  constructor(private http: HttpClient) { }

  layItemsTuUrl(id: any) {
    // window.alert(id);
    return this.http.get<GioHang[]>(this.url + 'giohangs/idTaiKhoan/' + id);
  }

  layItem(id: any) {
    return this.http.get<GioHang>(this.url + "giohangs/" + id);
  }

  getItems(): any {
    return this.items;
  }

  capNhatSoLuong(item: any) {
    return this.http.put(this.url + "giohangs", item);
  }

  clearCart() {
    this.items = [];
  }

  themVaoGioHang(item: any) {
    return this.http.post(this.url + "giohangs", item);
  }

  xoaGioHang(id: any) {
    return this.http.delete(this.url + "giohangs/" + id);
  }

  layGioHangTheoIdTKvaIdSP(idTK: any, idSP: any) {
    return this.http.get<GioHang[]>(this.url + "giohangs/idTaiKhoan/" + idTK + "/idSanPham/" + idSP);
  }
}
