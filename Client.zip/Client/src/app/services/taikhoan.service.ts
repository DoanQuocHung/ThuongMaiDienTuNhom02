import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { TaiKhoan } from '../models/tai-khoan.model';

@Injectable({
  providedIn: 'root'
})
export class TaikhoanService {

  // private taikhoan: any;
  url = environment.apiUrl;
  private taikhoanhienhanh: any; 

  constructor(private http: HttpClient) { }

  get taikhoan() {
    if (!this.taikhoanhienhanh) {
      this.taikhoanhienhanh = JSON.parse(localStorage.getItem("taikhoan") || '{}');
    }
    return this.taikhoanhienhanh;
  }

  set taikhoan(value) {
    this.taikhoanhienhanh = value;
    localStorage.setItem('taikhoan', JSON.stringify(value));
  }

  dangNhap(tendangnhap: string, matkhau: string) {
    return this.http.get(this.url + "taikhoans/dangNhap/" + tendangnhap + "/" + matkhau).pipe(
      map(data => this.taikhoan = data)
    );
  }

  layTaiKhoanTuUrlTheoId(id: any) {
    this.http.get<TaiKhoan>(this.url + 'taikhoans/' + id).subscribe(
      (result: TaiKhoan) =>{this.taikhoan = result}
    );
  }

  layTaiKhoan() {
    return this.taikhoan;
  }

  dangXuat() {
    this.taikhoanhienhanh = null;
    localStorage.removeItem('taikhoan');
  }
}
