import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ChiTietDonHang } from '../models/ChiTietDonHang';
import { DonHang } from '../models/DonHang';

@Injectable({
  providedIn: 'root'
})
export class DonhangService {
  url = environment.apiUrl;

  constructor(
    private http: HttpClient
  ) { }
  
  taoDonHang(donHang: DonHang) {
    return this.http.post(this.url + "donhangs", donHang);
  }

}
