import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { TaiKhoan } from 'src/app/models/tai-khoan.model';
import { QltaikhoanService } from '../shared/qltaikhoan.service';

@Component({
  selector: 'app-qltaikhoan',
  templateUrl: './qltaikhoan.component.html',
  styleUrls: ['./qltaikhoan.component.css']
})
export class QltaikhoanComponent implements OnInit {

  list : TaiKhoan[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service: QltaikhoanService, 
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.refreshList();
  }

  populateForm(selectedRecored: TaiKhoan){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete ?'))
    {
      this.service.deleteTaiKhoan(id)
      .subscribe(
        res=>{
          this.service.refreshList();
          this.toastr.error('Deleted successfully', 'Xóa thành công');
        },
        err=>{console.log(err)}
      )
    }
  }
}
