export class Qlnhanvien {
    idNV:number=0;
    //idTK:number=0;
    hotenNV:string='';
    ngaysinhNV:string='';
    sdtNV:string='';
    gioitinhNV:string='';
    diachiNV:string=''; 
}
