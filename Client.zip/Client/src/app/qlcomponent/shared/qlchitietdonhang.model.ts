export class Qlchitietdonhang {
    id: number
    idDH: string;
    tenSP: string;
    gia: number;
    soLuong: number;
}
