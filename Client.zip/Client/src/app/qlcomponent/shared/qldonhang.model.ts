export class Qldonhang {
    id: string;
    idTK: number=0;
    hoVaTen: string='';
    diaChi: string='';
    sdt: string='';
    tenCard: string='';
    soCard: string='';
    cvv: string='';
    tongTien: string='';
    ngayLap: string='';
    trangThai: number;
}
