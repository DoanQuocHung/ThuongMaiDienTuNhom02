export class Qlphanhoi {
    idPH:number=0;
    hotenPH:string='';
    sdtPH:string='';
    tieudePH:string='';
    noidungPH:string='';
}
