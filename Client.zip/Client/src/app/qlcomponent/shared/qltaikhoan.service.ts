import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { TaiKhoan } from 'src/app/models/tai-khoan.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class QltaikhoanService {

  readonly baseURL = 'https://localhost:5001/api/taikhoans';

  formData : TaiKhoan = new TaiKhoan();
  list : TaiKhoan[];
  private url = environment.apiUrl;
  private currentUser: any;

  constructor(private http: HttpClient) { }

  postTaiKhoan(){
    return this.http.post(this.baseURL, this.formData);
  }

  putTaiKhoan(){ 
    return this.http.put(`${this.baseURL}/${this.formData.idTK}`, this.formData);
  }

  deleteTaiKhoan(id:number){
    return this.http.delete(`${this.baseURL}/${id}`);
  }
 
  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as TaiKhoan[]);
  }


  
  get user() {
    if (!this.currentUser) {
      this.currentUser = JSON.parse(localStorage.getItem('user') || '{}');
    }
    return this.currentUser;
  }
  
  set user(value) {
    this.currentUser = value;
    localStorage.setItem('user', JSON.stringify(value));
  }

  login(values: any) {
    return this.http.post(this.url + 'api/takhoans/login', values).pipe(
      map(data => this.user = data)
    );
  }

  logout() {
    this.currentUser = null;
    localStorage.removeItem('user');
  }
}
