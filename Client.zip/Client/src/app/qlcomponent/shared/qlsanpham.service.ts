import { Injectable } from '@angular/core';
import { Qlsanpham } from './qlsanpham.model';
import { HttpClient} from '@angular/common/http';
import { CommonModule } from "@angular/common";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QlsanphamService {
 
  constructor(private http:HttpClient) { }

  readonly baseURL = 'https://localhost:5001/api/sanphams';

  formData : Qlsanpham = new Qlsanpham();
  list : Qlsanpham[];

  postSanPham(){
    return this.http.post(this.baseURL, this.formData);
  }

  putSanPham(){ 
    return this.http.put(`${this.baseURL}/${this.formData.id}`, this.formData);
  }

  deleteSanPham(id:number){
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qlsanpham[]);
  }

}
