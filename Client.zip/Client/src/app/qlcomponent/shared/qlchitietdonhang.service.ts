import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Qlchitietdonhang } from './qlchitietdonhang.model';

@Injectable({
  providedIn: 'root'
})
export class QlchitietdonhangService {

  readonly baseURL = 'https://localhost:5001/api/chitietdonhangs';

  formData : Qlchitietdonhang = new Qlchitietdonhang();
  list : Qlchitietdonhang[];

  constructor(private http:HttpClient) { }

  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qlchitietdonhang[]);
  }

  layChiTietTheoIdDH(idDH: String){
    this.http.get(this.baseURL +"/idDH/"+idDH)
    .toPromise()
    .then(res => this.list = res as Qlchitietdonhang[]);
  }
}
