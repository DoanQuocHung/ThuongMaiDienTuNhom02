import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { CommonModule } from "@angular/common";
import { Observable } from 'rxjs';
import { Qlnhanvien } from './qlnhanvien.model';

@Injectable({
  providedIn: 'root'
})
export class QlnhanvienService { 

  constructor(private http:HttpClient) { }

  readonly baseURL = 'https://localhost:5001/api/nhanviens';

  formData : Qlnhanvien = new Qlnhanvien();
  list : Qlnhanvien[];

  postNhanVien(){
    return this.http.post(this.baseURL, this.formData);
  }

  putNhanVien(){
    return this.http.put(`${this.baseURL}/${this.formData.idNV}`, this.formData);
  }

  deleteNhanVien(id:number){
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qlnhanvien[]);
  }
}
