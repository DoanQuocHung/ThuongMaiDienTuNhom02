import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Qldonhang } from './qldonhang.model';

@Injectable({
  providedIn: 'root'
})
export class QldonhangService {

  constructor(private http:HttpClient) { }

  readonly baseURL = 'https://localhost:5001/api/donhangs';

  formData : Qldonhang = new Qldonhang();
  list : Qldonhang[];

  putDonHang(){  
    return this.http.put(`${this.baseURL}/${this.formData.id}`, this.formData);
  }

  refreshList(){ 
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qldonhang[]);
  }
}
 