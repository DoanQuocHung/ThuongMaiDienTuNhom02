import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { CommonModule } from "@angular/common";
import { Observable } from 'rxjs';
import { Qlkhachhang } from './qlkhachhang.model';

@Injectable({
  providedIn: 'root'
})
export class QlkhachhangService {

  constructor(private http:HttpClient) { } 

  readonly baseURL = 'https://localhost:5001/api/khachhangs';

  formData : Qlkhachhang = new Qlkhachhang();
  list : Qlkhachhang[];

  postKhachHang(){
    return this.http.post(this.baseURL, this.formData);
  }

  putKhachHang(){
    return this.http.put(`${this.baseURL}/${this.formData.idKH}`, this.formData);
  }

  deleteKhachHang(id:number){
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qlkhachhang[]);
  }
}
