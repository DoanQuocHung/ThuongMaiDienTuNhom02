import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Qlphanhoi } from './qlphanhoi.model';

@Injectable({
  providedIn: 'root'
})
export class QlphanhoiService {

  constructor(private http:HttpClient) { }

  readonly baseURL = 'https://localhost:5001/api/phanhois';

  formData : Qlphanhoi = new Qlphanhoi(); 
  list : Qlphanhoi[];

  postPhanHoi(){
    return this.http.post(this.baseURL, this.formData);
  }

  deletePhanHoi(id:number){
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  refreshList(){
    this.http.get(this.baseURL)
    .toPromise()
    .then(res => this.list = res as Qlphanhoi[]);
  }
}
 