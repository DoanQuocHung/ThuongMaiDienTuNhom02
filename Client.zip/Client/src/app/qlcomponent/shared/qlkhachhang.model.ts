export class Qlkhachhang {
    idKH:number=0;
    //idTK:number=0;
    hotenKH:string='';
    ngaysinhKH:string='';
    sdtKH:string='';
    gioitinhKH:string='';
    diachiKH:string='';
}
