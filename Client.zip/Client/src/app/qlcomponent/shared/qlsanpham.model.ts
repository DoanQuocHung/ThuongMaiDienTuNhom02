export class Qlsanpham {
    id: number = 0;
    ten: string = '';
    gia: string = '';
    mausac: string = '';
    soluong: string = '';
    kichthuocmat: string = '';
    matkinh: string = '';
    chatlieuday: string = '';
    gioitinh: string = '';
    phongcach: string = '';
    fileanh: string = '';
}