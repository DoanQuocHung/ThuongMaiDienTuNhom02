import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Qlchitietdonhang } from '../shared/qlchitietdonhang.model';
import { QlchitietdonhangService } from '../shared/qlchitietdonhang.service';

@Component({
  selector: 'app-qlchitietdonhang',
  templateUrl: './qlchitietdonhang.component.html',
  styleUrls: ['./qlchitietdonhang.component.css']
})
export class QlchitietdonhangComponent implements OnInit {

  list : Qlchitietdonhang[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service:QlchitietdonhangService,
    private toastr:ToastrService) {}

  ngOnInit(): void {
    //this.service.refreshList();
  }

  populateForm(selectedRecored: Qlchitietdonhang){
    this.service.formData = Object.assign({}, selectedRecored);
  }

}
