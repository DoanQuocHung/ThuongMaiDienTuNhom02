import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlchitietdonhangComponent } from './qlchitietdonhang.component';

describe('QlchitietdonhangComponent', () => {
  let component: QlchitietdonhangComponent;
  let fixture: ComponentFixture<QlchitietdonhangComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlchitietdonhangComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlchitietdonhangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
