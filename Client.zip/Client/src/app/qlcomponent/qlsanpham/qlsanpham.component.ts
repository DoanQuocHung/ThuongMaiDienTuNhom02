import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlsanpham } from '../shared/qlsanpham.model';
import { QlsanphamService } from '../shared/qlsanpham.service';
import { CommonModule } from "@angular/common";

@Component({
  selector: 'app-qlsanpham',
  templateUrl: './qlsanpham.component.html',
  styleUrls: ['./qlsanpham.component.css']
})
export class QlsanphamComponent implements OnInit {

  list : Qlsanpham[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service:QlsanphamService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.refreshList();
  }

  populateForm(selectedRecored: Qlsanpham){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete ?'))
    {
      this.service.deleteSanPham(id)
      .subscribe(
        res=>{
          this.service.refreshList();
          this.toastr.error('Deleted successfully', 'Xóa thành công');
        },
        err=>{console.log(err)}
      )
    }
  }
}
