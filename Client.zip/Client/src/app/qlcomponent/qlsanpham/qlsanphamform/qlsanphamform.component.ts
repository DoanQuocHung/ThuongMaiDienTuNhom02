import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlsanpham } from '../../shared/qlsanpham.model';
import { QlsanphamService } from '../../shared/qlsanpham.service';

@Component({
  selector: 'app-qlsanphamform',
  templateUrl: './qlsanphamform.component.html',
  styleUrls: ['./qlsanphamform.component.css']
})
export class QlsanphamformComponent implements OnInit {

  constructor(public service : QlsanphamService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    if(this.service.formData.id == 0)
      this.insertRecord(form);
    else
      this.updateRecord(form);
  }

  insertRecord(form:NgForm){
    this.service.postSanPham().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.success('Submitted successfully', 'Thêm thành công');
      },
      err =>{console.log(err)}
    );
  }

  updateRecord(form:NgForm){
    this.service.putSanPham().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.info('Updated successfully', 'Sửa thành công');
      },
      err =>{console.log(err)}
    );
  }

  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData = new Qlsanpham();
  }
}
