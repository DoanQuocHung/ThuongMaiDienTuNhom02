import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlsanphamformComponent } from './qlsanphamform.component';

describe('QlsanphamformComponent', () => {
  let component: QlsanphamformComponent;
  let fixture: ComponentFixture<QlsanphamformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlsanphamformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlsanphamformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
