import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlkhachhang } from '../shared/qlkhachhang.model';
import { QlkhachhangService } from '../shared/qlkhachhang.service';

@Component({
  selector: 'app-qlkhachhang',
  templateUrl: './qlkhachhang.component.html',
  styleUrls: ['./qlkhachhang.component.css']
})
export class QlkhachhangComponent implements OnInit {

  list : Qlkhachhang[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service:QlkhachhangService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.refreshList();
  } 

  populateForm(selectedRecored: Qlkhachhang){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete ?'))
    {
      this.service.deleteKhachHang(id)
      .subscribe(
        res=>{
          this.service.refreshList();
          this.toastr.error('Deleted successfully', 'Xóa thành công');
        },
        err=>{console.log(err)}
      )
    }
  }
}
