import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlkhachhangformComponent } from './qlkhachhangform.component';

describe('QlkhachhangformComponent', () => {
  let component: QlkhachhangformComponent;
  let fixture: ComponentFixture<QlkhachhangformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlkhachhangformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlkhachhangformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
