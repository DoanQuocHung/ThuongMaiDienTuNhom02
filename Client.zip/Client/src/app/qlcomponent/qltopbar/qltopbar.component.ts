import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaikhoanService } from 'src/app/services/taikhoan.service';

@Component({
  selector: 'app-qltopbar',
  templateUrl: './qltopbar.component.html',
  styleUrls: ['./qltopbar.component.css']
})
export class QltopbarComponent implements OnInit {

  constructor(
    private taiKhoanService: TaikhoanService,
    private router: Router
  ) { }

  ngOnInit(): void {
  }

  dangXuat(){
    this.taiKhoanService.dangXuat();
    this.router.navigate(['dangnhap']);
  }
}
