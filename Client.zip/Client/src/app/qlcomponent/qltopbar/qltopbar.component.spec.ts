import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QltopbarComponent } from './qltopbar.component';

describe('QltopbarComponent', () => {
  let component: QltopbarComponent;
  let fixture: ComponentFixture<QltopbarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QltopbarComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QltopbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
