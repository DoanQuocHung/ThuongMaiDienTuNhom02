import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlleftmenuComponent } from './qlleftmenu.component';

describe('QlleftmenuComponent', () => {
  let component: QlleftmenuComponent;
  let fixture: ComponentFixture<QlleftmenuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlleftmenuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlleftmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
