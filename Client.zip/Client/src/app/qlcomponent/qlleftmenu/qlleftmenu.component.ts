import { Component, OnInit } from '@angular/core';
import { TaiKhoan } from 'src/app/models/tai-khoan.model';
import { TaikhoanService } from 'src/app/services/taikhoan.service';

@Component({
  selector: 'app-qlleftmenu',
  templateUrl: './qlleftmenu.component.html',
  styleUrls: ['./qlleftmenu.component.css']
})
export class QlleftmenuComponent implements OnInit {

  list : TaiKhoan[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service: TaikhoanService) { }

  ngOnInit(): void {
    // this.service.refreshList();
  }

  populateForm(selectedRecored: TaiKhoan){
    // this.service.formData = Object.assign({}, selectedRecored);
  }

}
