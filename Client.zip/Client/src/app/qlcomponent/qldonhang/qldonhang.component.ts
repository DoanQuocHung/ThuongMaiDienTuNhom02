import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ChitietdonhangService } from 'src/app/services/chitietdonhang.service';
import { QlchitietdonhangService } from '../shared/qlchitietdonhang.service';
import { Qldonhang } from '../shared/qldonhang.model';
import { QldonhangService } from '../shared/qldonhang.service';

@Component({
  selector: 'app-qldonhang',
  templateUrl: './qldonhang.component.html',
  styleUrls: ['./qldonhang.component.css']
})
export class QldonhangComponent implements OnInit {

  list : Qldonhang[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service:QldonhangService,
    private toastr:ToastrService,
    private chiTietDonHang: QlchitietdonhangService) { }

  ngOnInit(): void {
    this.service.refreshList();
  }

  populateForm(selectedRecored: Qldonhang){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  layChiTietDonHang(idDH: String){
    this.chiTietDonHang.layChiTietTheoIdDH(idDH);
  }
}
