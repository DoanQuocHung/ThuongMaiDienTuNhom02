import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qldonhang } from '../../shared/qldonhang.model';
import { QldonhangService } from '../../shared/qldonhang.service';

@Component({
  selector: 'app-qldonhangform',
  templateUrl: './qldonhangform.component.html',
  styleUrls: ['./qldonhangform.component.css']
})
export class QldonhangformComponent implements OnInit {

  constructor(public service : QldonhangService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
      this.updateRecord(form);
  }

  updateRecord(form:NgForm){
    this.service.putDonHang().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.info('Updated successfully', 'Sửa thành công');
      },
      err =>{console.log(err)}
    );
  }

  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData = new Qldonhang();
  }
} 
