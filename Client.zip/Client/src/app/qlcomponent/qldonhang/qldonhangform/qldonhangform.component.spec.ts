import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QldonhangformComponent } from './qldonhangform.component';

describe('QldonhangformComponent', () => {
  let component: QldonhangformComponent;
  let fixture: ComponentFixture<QldonhangformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QldonhangformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QldonhangformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
