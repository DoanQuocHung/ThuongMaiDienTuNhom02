import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QldonhangComponent } from './qldonhang.component';

describe('QldonhangComponent', () => {
  let component: QldonhangComponent;
  let fixture: ComponentFixture<QldonhangComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QldonhangComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QldonhangComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
