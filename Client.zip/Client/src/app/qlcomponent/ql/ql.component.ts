import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ql',
  templateUrl: './ql.component.html',
  styleUrls: ['./ql.component.css']
})
export class QlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  
}
