import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlnhanvien } from '../../shared/qlnhanvien.model';
import { QlnhanvienService } from '../../shared/qlnhanvien.service';

@Component({
  selector: 'app-qlnhanvienform',
  templateUrl: './qlnhanvienform.component.html',
  styleUrls: ['./qlnhanvienform.component.css']
})
export class QlnhanvienformComponent implements OnInit {

  constructor(public service : QlnhanvienService,
    private toastr:ToastrService) { }
 
  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    if(this.service.formData.idNV == 0)
      this.insertRecord(form);
    else  
      this.updateRecord(form);
  }

  insertRecord(form:NgForm){
    this.service.postNhanVien().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.success('Submitted successfully', 'Thêm thành công');
      },
      err =>{console.log(err)}
    );
  }

  updateRecord(form:NgForm){
    this.service.putNhanVien().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.info('Updated successfully', 'Sửa thành công');
      },
      err =>{console.log(err)}
    );
  }

  resetForm(form:NgForm){
    form.form.reset();
    this.service.formData = new Qlnhanvien();
  }
}
