import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlnhanvienformComponent } from './qlnhanvienform.component';

describe('QlnhanvienformComponent', () => {
  let component: QlnhanvienformComponent;
  let fixture: ComponentFixture<QlnhanvienformComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlnhanvienformComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlnhanvienformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
