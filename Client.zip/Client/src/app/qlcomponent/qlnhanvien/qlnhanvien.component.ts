import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlnhanvien } from '../shared/qlnhanvien.model';
import { QlnhanvienService } from '../shared/qlnhanvien.service';

@Component({
  selector: 'app-qlnhanvien',
  templateUrl: './qlnhanvien.component.html',
  styleUrls: ['./qlnhanvien.component.css']
})
export class QlnhanvienComponent implements OnInit {

  list : Qlnhanvien[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service:QlnhanvienService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
    this.service.refreshList();
  }
 
  populateForm(selectedRecored: Qlnhanvien){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete ?'))
    {
      this.service.deleteNhanVien(id)
      .subscribe(
        res=>{
          this.service.refreshList();
          this.toastr.error('Deleted successfully', 'Xóa thành công');
        },
        err=>{console.log(err)}
      )
    }
  }
}
