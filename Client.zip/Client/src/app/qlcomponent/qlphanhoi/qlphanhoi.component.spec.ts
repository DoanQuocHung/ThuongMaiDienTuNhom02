import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QlphanhoiComponent } from './qlphanhoi.component';

describe('QlphanhoiComponent', () => {
  let component: QlphanhoiComponent;
  let fixture: ComponentFixture<QlphanhoiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QlphanhoiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QlphanhoiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
