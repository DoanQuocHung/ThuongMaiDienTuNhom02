import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Qlphanhoi } from '../shared/qlphanhoi.model';
import { QlphanhoiService } from '../shared/qlphanhoi.service';

@Component({
  selector: 'app-qlphanhoi',
  templateUrl: './qlphanhoi.component.html',
  styleUrls: ['./qlphanhoi.component.css']
})
export class QlphanhoiComponent implements OnInit {

  list : Qlphanhoi[];
  totalLength: any;
  page: number = 1;
  showpost: any = [];

  constructor(public service: QlphanhoiService,
    private toastr:ToastrService) { }


  ngOnInit(): void {
    this.service.refreshList();
    console.log(this.service.list);
  }

  populateForm(selectedRecored: Qlphanhoi){
    this.service.formData = Object.assign({}, selectedRecored);
  }

  onDelete(id:number){
    if(confirm('Are you sure to delete ?'))
    {
      this.service.deletePhanHoi(id)
      .subscribe(
        res=>{
          this.service.refreshList();
          this.toastr.error('Deleted successfully', 'Xóa thành công');
        },
        err=>{console.log(err)}
      )
    }
  }
}
