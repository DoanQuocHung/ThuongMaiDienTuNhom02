import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule} from 'ngx-toastr';
import { NgxPaginationModule } from 'ngx-pagination';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QlleftmenuComponent } from './qlcomponent/qlleftmenu/qlleftmenu.component';
import { QltopbarComponent } from './qlcomponent/qltopbar/qltopbar.component';
import { QlsanphamComponent } from './qlcomponent/qlsanpham/qlsanpham.component';
import { QlnhanvienComponent } from './qlcomponent/qlnhanvien/qlnhanvien.component';
import { QlsanphamformComponent } from './qlcomponent/qlsanpham/qlsanphamform/qlsanphamform.component';
import { QlkhachhangComponent } from './qlcomponent/qlkhachhang/qlkhachhang.component';
import { QlkhachhangformComponent } from './qlcomponent/qlkhachhang/qlkhachhangform/qlkhachhangform.component';
import { QlnhanvienformComponent } from './qlcomponent/qlnhanvien/qlnhanvienform/qlnhanvienform.component';
import { DangnhapComponent } from './dangnhap/dangnhap.component';
import { DangkiComponent } from './dangki/dangki.component';
import { QlComponent } from './qlcomponent/ql/ql.component';
import { router_ql } from './router_ql.router';
import { TrangchuComponent } from './trangchu/trangchu.component';
import { BottomBarComponent } from './trangchu/bottom-bar/bottom-bar.component';
import { ChitietsanphamComponent } from './trangchu/chitietsanpham/chitietsanpham.component';
import { DanhsachsanphamComponent } from './trangchu/danhsachsanpham/danhsachsanpham.component';
import { GiohangComponent } from './trangchu/giohang/giohang.component';
import { TopBarComponent } from './trangchu/top-bar/top-bar.component';
import { AuthService } from './services/auth.service';
import { AlertifyService } from './services/alertify.service';
import { QltaikhoanComponent } from './qlcomponent/qltaikhoan/qltaikhoan.component';
import { DonhangComponent } from './trangchu/donhang/donhang.component';
import { QldonhangComponent } from './qlcomponent/qldonhang/qldonhang.component';
import { QldonhangformComponent } from './qlcomponent/qldonhang/qldonhangform/qldonhangform.component';
import { QlchitietdonhangComponent } from './qlcomponent/qlchitietdonhang/qlchitietdonhang.component';
import { PhanhoiComponent } from './trangchu/phanhoi/phanhoi.component';
import { QlphanhoiComponent } from './qlcomponent/qlphanhoi/qlphanhoi.component';
import { GioithieuComponent } from './trangchu/gioithieu/gioithieu.component';

@NgModule({
  declarations: [
    AppComponent,
    QlleftmenuComponent,
    QltopbarComponent,
    QlsanphamComponent,
    QlnhanvienComponent,
    QlsanphamformComponent,
    QlkhachhangComponent,
    QlkhachhangformComponent,
    QlnhanvienformComponent,
    DangnhapComponent,
    DangkiComponent,
    QlComponent,
    TrangchuComponent,
    BottomBarComponent,
    ChitietsanphamComponent,
    DanhsachsanphamComponent,
    GiohangComponent,
    TopBarComponent,
    QltaikhoanComponent,
    DonhangComponent,
    QldonhangComponent,
    QldonhangformComponent,
    QlchitietdonhangComponent,
    PhanhoiComponent,
    QlphanhoiComponent,
    GioithieuComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    NgxPaginationModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(router_ql)
  ],
  providers: [
    AuthService,
    AlertifyService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
