export class ChiTietDonHang {
    id: number
    idDH: string;
    tenSP: string;
    gia: number;
    soLuong: number;
}