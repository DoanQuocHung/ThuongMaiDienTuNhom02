export class GioHang {
    id: number;
    idTK: number;
    idSP: number;
    tenSP: string;
    gia: number;
    soLuong: number;
}
