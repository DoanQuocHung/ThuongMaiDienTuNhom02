export class TaiKhoan {
    idTK: number=0;
    idPQ: number=3;
    tenTK: string='';
    matkhauTK: string='';

    // id: number;
    // tenDangNhap: string;
    // matKhau: string;
}
