// import { Time } from "@angular/common";
// import { ChiTietDonHang } from "./ChiTietDonHang";

export class DonHang {
    id: string;
    idTK: number;
    hoVaTen: string;
    diaChi: string;
    sdt: string;
    tenCard: string;
    soCard: string;
    cvv: string;
    tongTien: string;
    ngayLap: string;
    trangThai: number;
}