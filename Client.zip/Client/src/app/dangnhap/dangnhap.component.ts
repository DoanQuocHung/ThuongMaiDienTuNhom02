import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ToastrService } from 'ngx-toastr';
import { QltaikhoanService } from '../qlcomponent/shared/qltaikhoan.service';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { TaiKhoan } from '../models/tai-khoan.model';
import { TaikhoanService } from '../services/taikhoan.service';

@Component({
  selector: 'app-dangnhap',
  templateUrl: './dangnhap.component.html',
  styleUrls: ['./dangnhap.component.css']
})
export class DangnhapComponent implements OnInit {

  loginForm = new FormGroup({
    tendangnhap: new FormControl('', [Validators.required]),
    matkhau: new FormControl('', [Validators.required, Validators.minLength(5)])
  });
  errorMsg = '';
  private returnUrl: any;

  constructor(private router: Router,
    private route: ActivatedRoute,
    private taiKhoanService: TaikhoanService,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.returnUrl = this.route.snapshot.queryParams.returnUrl || '/';
  }

  get tendangnhap() { return this.loginForm.controls['tendangnhap']; }
  get matkhau() { return this.loginForm.controls['matkhau']; }

  onSubmit() {
    this.taiKhoanService.dangNhap(this.tendangnhap.value, this.matkhau.value)
      .subscribe(
        () => {
          if (this.taiKhoanService.taikhoan.idPQ == 3) {
            this.router.navigate(['']);
          } else if (this.taiKhoanService.taikhoan.idPQ == 2 || this.taiKhoanService.taikhoan.idPQ == 1) {
            this.router.navigate(['/quanly']);
          }
        },
        error => {
          this.errorMsg = error.error;
          this.toastr.error('Login fail', error.error);
        });

  }
}
