import { Routes } from "@angular/router";
import { DangkiComponent } from "./dangki/dangki.component";
import { DangnhapComponent } from "./dangnhap/dangnhap.component";
import { QlComponent } from "./qlcomponent/ql/ql.component";
import { QldonhangComponent } from "./qlcomponent/qldonhang/qldonhang.component";
import { QlkhachhangComponent } from "./qlcomponent/qlkhachhang/qlkhachhang.component";
import { QlnhanvienComponent } from "./qlcomponent/qlnhanvien/qlnhanvien.component";
import { QlphanhoiComponent } from "./qlcomponent/qlphanhoi/qlphanhoi.component";
import { QlsanphamComponent } from "./qlcomponent/qlsanpham/qlsanpham.component";
import { QltaikhoanComponent } from "./qlcomponent/qltaikhoan/qltaikhoan.component";
import { ChitietsanphamComponent } from "./trangchu/chitietsanpham/chitietsanpham.component";
import { DanhsachsanphamComponent } from "./trangchu/danhsachsanpham/danhsachsanpham.component";
import { DonhangComponent } from "./trangchu/donhang/donhang.component";
import { GiohangComponent } from "./trangchu/giohang/giohang.component";
import { GioithieuComponent } from "./trangchu/gioithieu/gioithieu.component";
import { PhanhoiComponent } from "./trangchu/phanhoi/phanhoi.component";
import { TrangchuComponent } from "./trangchu/trangchu.component";

export const router_ql: Routes = [
  {
    path: 'dangnhap',
    component: DangnhapComponent
  },
  {
    path: 'dangki',
    component: DangkiComponent
  },
  {
    path: 'quanly',
    component: QlComponent,
    children: [
      { path: 'sanpham', component: QlsanphamComponent },
      { path: 'nhanvien', component: QlnhanvienComponent },
      { path: 'khachhang', component: QlkhachhangComponent },
      { path: 'taikhoan', component: QltaikhoanComponent },
      { path: 'phanhoi', component: QlphanhoiComponent },
      { path: 'donhang', component: QldonhangComponent }
    ]
  },
  {
    path: '',
    component: TrangchuComponent,
    children: [
      {
        path: '',
        component: DanhsachsanphamComponent
      },
      {
        path: 'gioitinhnam/:luachon',
        component: DanhsachsanphamComponent
      },
      {
        path: 'gioitinhnu/:luachon',
        component: DanhsachsanphamComponent
      },
      {
        path: 'dongian/:luachon',
        component: DanhsachsanphamComponent
      },
      {
        path: 'catinh/:luachon',
        component: DanhsachsanphamComponent
      },
      {
        path: 'hiendai/:luachon',
        component: DanhsachsanphamComponent
      },
      {
        path: 'sanphams/:id',
        component: ChitietsanphamComponent
      },
      {
        path: 'giohang',
        component: GiohangComponent
      },
      {
        path: 'donhang',
        component: DonhangComponent
      },
      {
        path: 'gioithieu',
        component: GioithieuComponent
      }
    ]
  },
  {
    path: 'phanhoi',
    component: PhanhoiComponent
  }
];