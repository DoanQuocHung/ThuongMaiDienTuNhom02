import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Qlsanpham } from 'src/app/qlcomponent/shared/qlsanpham.model';
import { SanphamService } from 'src/app/services/sanpham.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-danhsachsanpham',
  templateUrl: './danhsachsanpham.component.html',
  styleUrls: ['./danhsachsanpham.component.css']
})
export class DanhsachsanphamComponent implements OnInit {

  public urlSanPham = environment.imageUrl;
  public kieusapxep: string = "....";
  constructor(private route: ActivatedRoute,
    private sanPhamService: SanphamService) { }

  slideIndex = 1;

  plusSlides(n: any) {
    this.showSlides(this.slideIndex += n);
  }

  showSlides(n: any) {
    const slides = document.getElementsByClassName("mySlides") as HTMLCollectionOf<HTMLElement>;
    if (n > slides.length) { this.slideIndex = 1; }
    if (n < 1) { this.slideIndex = slides.length; }
    for (let i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
    }
    slides[this.slideIndex - 1].style.display = "block";
  }

  totalLength: any;
  page: number = 1;

  showpost: any = [];

  ngOnInit(): void {
    const ksx = document.getElementById(this.kieusapxep) as HTMLElement;
    ksx.style.color = "gray";
    if (this.route.snapshot.paramMap.get('luachon') == null) {
      this.sanPhamService.getProducts().subscribe((result: any) => {
        this.showpost = result;
        this.totalLength = result.length;
        console.log(this.showpost)
      });
    } else {
      let giotinh: string = String(this.route.snapshot.paramMap.get('luachon'));
      this.sanPhamService.laySanPhamTheoGioiTinh(giotinh).subscribe(
        (result: any) => {
          this.showpost = result;
          this.totalLength = result.length;
          console.log(this.showpost)
        });
    }
  }

  xuLySapXep(kieusapxep: string) {
    if (kieusapxep == "....") {
      this.kieusapxep = "...."
      if (this.route.snapshot.paramMap.get('luachon') == null) {
        this.sanPhamService.getProducts().subscribe((result: any) => {
          this.showpost = result;
          this.totalLength = result.length;
          console.log(this.showpost)
        });
      } else {
        let giotinh: string = String(this.route.snapshot.paramMap.get('luachon'));
        this.sanPhamService.laySanPhamTheoGioiTinh(giotinh).subscribe(
          (result: any) => {
            this.showpost = result;
            this.totalLength = result.length;
            console.log(this.showpost)
          });
      }
    } else if (kieusapxep == "giatangdan") {
      this.kieusapxep = "Giá tăng dần";
      if (this.route.snapshot.paramMap.get('luachon') == null) {
        this.sanPhamService.getProducts().subscribe((result: any) => {
          this.showpost = result;
          for (let i = 0; i < this.showpost.length - 1; i++) {
            for (let j = i + 1; j < this.showpost.length; j++) {
              if (Number(this.showpost[i].gia) > Number(this.showpost[j].gia)) {
                let sp: Qlsanpham = this.showpost[i];
                this.showpost[i] = this.showpost[j];
                this.showpost[j] = sp;
              }
            }
          }
          this.totalLength = result.length;
          console.log(this.showpost)
        });
      } else {
        let giotinh: string = String(this.route.snapshot.paramMap.get('luachon'));
        this.sanPhamService.laySanPhamTheoGioiTinh(giotinh).subscribe(
          (result: any) => {
            this.showpost = result;
            for (let i = 0; i < this.showpost.length - 1; i++) {
              for (let j = i + 1; j < this.showpost.length; j++) {
                if (Number(this.showpost[i].gia) > Number(this.showpost[j].gia)) {
                  let sp: Qlsanpham = this.showpost[i];
                  this.showpost[i] = this.showpost[j];
                  this.showpost[j] = sp;
                }
              }
            }
            this.totalLength = result.length;
            console.log(this.showpost)
          });
      }
    } else if (kieusapxep == "giagiamdan") {
      this.kieusapxep = "Giá giảm dần";
      if (this.route.snapshot.paramMap.get('luachon') == null) {
        this.sanPhamService.getProducts().subscribe((result: any) => {
          this.showpost = result;
          for (let i = 0; i < this.showpost.length - 1; i++) {
            for (let j = i + 1; j < this.showpost.length; j++) {
              if (Number(this.showpost[i].gia) < Number(this.showpost[j].gia)) {
                let sp: Qlsanpham = this.showpost[i];
                this.showpost[i] = this.showpost[j];
                this.showpost[j] = sp;
              }
            }
          }
          this.totalLength = result.length;
          console.log(this.showpost)
        });
      } else {
        let giotinh: string = String(this.route.snapshot.paramMap.get('luachon'));
        this.sanPhamService.laySanPhamTheoGioiTinh(giotinh).subscribe(
          (result: any) => {
            this.showpost = result;
            for (let i = 0; i < this.showpost.length - 1; i++) {
              for (let j = i + 1; j < this.showpost.length; j++) {
                if (Number(this.showpost[i].gia) < Number(this.showpost[j].gia)) {
                  let sp: Qlsanpham = this.showpost[i];
                  this.showpost[i] = this.showpost[j];
                  this.showpost[j] = sp;
                }
              }
            }
            this.totalLength = result.length;
            console.log(this.showpost)
          });
      }
    }
  }
}
