import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GioHang } from 'src/app/models/gio-hang.model';
import { GiohangService } from 'src/app/services/giohang.service';
import { SanphamService } from 'src/app/services/sanpham.service';
import { TaikhoanService } from 'src/app/services/taikhoan.service';

@Component({
  selector: 'app-giohang',
  templateUrl: './giohang.component.html',
  styleUrls: ['./giohang.component.css']
})
export class GiohangComponent implements OnInit {

  items: GioHang[] = [];
  tong: number = 0;
  taikhoan: any = this.taiKhoanService.layTaiKhoan();

  constructor(
    private gioHangService: GiohangService,
    public taiKhoanService: TaikhoanService,
    private sanPhamService: SanphamService,
    public router: Router
  ) { }

  ngOnInit() {
    if (localStorage.getItem('taikhoan') != null) {
      this.gioHangService.layItemsTuUrl(this.taiKhoanService.taikhoan.idTK).subscribe(
        (result: GioHang[]) => {
          this.items = result;
          this.tinhTong();
          // window.alert(this.items);
        }
      );
    }
  }

  capNhatSoLuong(id: number, value: any) {
    let item: GioHang;
    this.gioHangService.layItem(id).subscribe(
      (result: GioHang) => {
        item = result;
        item.soLuong = value;
        this.gioHangService.capNhatSoLuong(item).subscribe(
          () => {
            this.gioHangService.layItemsTuUrl(this.taiKhoanService.taikhoan.idTK).subscribe(
              (result: GioHang[]) => {
                this.items = result;
                this.tong = 0;
                this.tinhTong();
              }
            );
          }
        );
      }
    );

  }

  tinhTong() {
    if (localStorage.getItem('taikhoan') != null) {
      let soLuong: number;
      if (this.items != null) {
        this.items.forEach((item: GioHang) => {
          soLuong = item.soLuong;
          this.tong += soLuong * item.gia;
        });
      }
    }
  }

  xoaGioHang(id: any) {
    const a = this.gioHangService.xoaGioHang(id).subscribe(
      () => {
        this.gioHangService.layItemsTuUrl(this.taiKhoanService.taikhoan.idTK).subscribe(
          (result: GioHang[]) => {
            this.items = result;
            this.tong = 0;
            this.tinhTong();
          }
        );
      }
    );
  }

  isDisabled() {
    if (localStorage.getItem('taikhoan') != null) {
      if (this.items.length > 0) {
        return false;
      }
      return true;
    }

    return true;
  }

  taiKhoanHienHang() {
    if (localStorage.getItem('taikhoan') != null) {
      return true;
    }

    return false;
  }
}
