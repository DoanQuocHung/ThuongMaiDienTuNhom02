import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaikhoanService } from 'src/app/services/taikhoan.service';

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.css']
})
export class TopBarComponent implements OnInit {
  public Nam: string = "nam";
  constructor(public taiKhoanService: TaikhoanService,
    private router: Router) { }

  ngOnInit(): void {
  }

  dangXuat() {
    this.taiKhoanService.dangXuat();
    this.router.navigate(['']);
  }

  taiKhoanHienHang() {
    if (localStorage.getItem('taikhoan') != null) {
      return true;
    }

    return false;
  }
}
