import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Qlphanhoi } from 'src/app/qlcomponent/shared/qlphanhoi.model';
import { QlphanhoiService } from 'src/app/qlcomponent/shared/qlphanhoi.service';

@Component({
  selector: 'app-phanhoi',
  templateUrl: './phanhoi.component.html',
  styleUrls: ['./phanhoi.component.css']
})
export class PhanhoiComponent implements OnInit {

  constructor(public service : QlphanhoiService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    this.register(form);
  }

  register(form:NgForm){
    this.service.postPhanHoi().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.success('Successfully', 'Phản hồi thành công');
      },
      err =>{console.log(err)}
    );
  }

  resetForm(form:NgForm){ 
    form.form.reset();
    this.service.formData = new Qlphanhoi();
  }
}
