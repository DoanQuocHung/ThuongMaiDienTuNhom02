import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GioHang } from 'src/app/models/gio-hang.model';
import { Qlsanpham } from 'src/app/qlcomponent/shared/qlsanpham.model';
import { GiohangService } from 'src/app/services/giohang.service';
import { SanphamService } from 'src/app/services/sanpham.service';
import { TaikhoanService } from 'src/app/services/taikhoan.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-chitietsanpham',
  templateUrl: './chitietsanpham.component.html',
  styleUrls: ['./chitietsanpham.component.css']
})
export class ChitietsanphamComponent implements OnInit {

  urlSanPham = environment.imageUrl;
  sanpham: any = [];
  thongSoKyThuat: any = [];
  n: number = 0;
  j: number = 0;
  item: any = { idTK: Number, idSP: Number, tenSP: String, gia: Number, soLuong: Number };

  constructor(
    private route: ActivatedRoute,
    private gioHangService: GiohangService,
    private sanPhamService: SanphamService,
    private http: HttpClient,
    private taiKhoanService: TaikhoanService) { }

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.sanPhamService.getProduct(id).subscribe((result: any) => {
      this.sanpham = result;
      // console.log(this.sanpham);

    });
  }

  themVaoGioHang(sanpham: Qlsanpham, value: any) {
    if (value <= 0) {
      window.alert("Số lượng phải lớn hơn 0");
    } else {
      if (localStorage.getItem('taikhoan') != null) {
        let item: GioHang;
        this.gioHangService.layGioHangTheoIdTKvaIdSP(this.taiKhoanService.taikhoan.idTK, sanpham.id).subscribe(
          (result: GioHang[]) => {
            item = result[0];
            console.log(item);
            if (item != null) {
              let a: number = item.soLuong;
              let b: number = Number.parseInt(value);
              a += b;
              item.soLuong = a;
              if (item.soLuong > Number.parseInt(sanpham.soluong)) {
                window.alert("Vượt quá số lượng sản phẩm hiện có")
              } else {
                this.gioHangService.capNhatSoLuong(item).subscribe(
                  () => { window.alert("Da bo sung so luong san pham vao gio hang"); }
                );
              }
            } else {
              if (value > Number.parseInt(sanpham.soluong)) {
                window.alert("Vượt quá số lượng sản phẩm hiện có")
              } else {
                const taiKhoan = this.taiKhoanService.layTaiKhoan();
                this.item.idTK = taiKhoan.idTK;
                this.item.idSP = sanpham.id;
                this.item.tenSP = sanpham.ten;
                this.item.gia = sanpham.gia;
                this.item.soLuong = value;
                this.gioHangService.themVaoGioHang(this.item).subscribe(
                  () => { window.alert("Da them san pham vao gio hang") }
                );
              }
            }
          }
        );
      } else {
        window.alert("Bạn phải đăng nhập để thêm vào giỏ hàng");
      }
    }
  }
}
