import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
// import { timeStamp } from 'console';
import { elementAt } from 'rxjs/operators';
import { ChiTietDonHang } from 'src/app/models/ChiTietDonHang';
import { DonHang } from 'src/app/models/DonHang';
import { GioHang } from 'src/app/models/gio-hang.model';
import { Qlsanpham } from 'src/app/qlcomponent/shared/qlsanpham.model';
import { ChitietdonhangService } from 'src/app/services/chitietdonhang.service';
import { DonhangService } from 'src/app/services/donhang.service';
import { GiohangService } from 'src/app/services/giohang.service';
import { SanphamService } from 'src/app/services/sanpham.service';
import { TaikhoanService } from 'src/app/services/taikhoan.service';

@Component({
  selector: 'app-donhang',
  templateUrl: './donhang.component.html',
  styleUrls: ['./donhang.component.css']
})
export class DonhangComponent implements OnInit {
  items: GioHang[];
  tong: number = 0;
  checkoutForm = this.formBuilder.group({
    hovaten: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]*')]),
    diachi: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z0-9 /]*')]),
    sdt: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10), Validators.pattern('^[0-9]*')]),
    tencard: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]*')]),
    socard: new FormControl('', [Validators.required, Validators.minLength(16), Validators.maxLength(16), Validators.pattern('^[0-9]*')]),
    cvv: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(4), Validators.pattern('^[0-9]*')]),
  });
  idDH: string;
  constructor(
    private gioHangService: GiohangService,
    private taiKhoanService: TaikhoanService,
    private formBuilder: FormBuilder,
    private router: Router,
    private donHangService: DonhangService,
    private chiTietDonHangService: ChitietdonhangService,
    private sanPhamService: SanphamService
  ) { }

  ngOnInit() {
    if (localStorage.getItem('taikhoan') == null) {
      this.router.navigate(['']);
    }
    this.gioHangService.layItemsTuUrl(this.taiKhoanService.taikhoan.idTK).subscribe(
      (result: GioHang[]) => {
        this.items = result;
        // this.isDisabled();
        this.tinhTong();
      }
    );
  }

  get hovaten() {
    return this.checkoutForm.controls['hovaten'];
  }

  get diachi() {
    return this.checkoutForm.controls['diachi'];
  }

  get sdt() {
    return this.checkoutForm.controls['sdt'];
  }

  get tencard() {
    return this.checkoutForm.controls['tencard'];
  }

  get socard() {
    return this.checkoutForm.controls['socard'];
  }

  get cvv() {
    return this.checkoutForm.controls['cvv'];
  }


  tinhTong() {
    let soLuong: number;
    if (this.items != null) {
      this.items.forEach(item => {
        soLuong = item.soLuong;
        this.tong += soLuong * item.gia;
      });
    }
  }

  thanhToan() {
    var time = new Date();
    var ngayLap = time.getFullYear() + "-" + (time.getMonth() + 1) + "-" + time.getDate() + " "
      + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds() + "." + time.getUTCMilliseconds();
    var getTime = time.getTime();
    this.checkout(ngayLap, getTime);
  }

  checkout(ngayLap: string, getTime: number) {
    this.idDH = this.taiKhoanService.taikhoan.idTK.toString() + getTime.toString();
    var i = new Number(this.tong)
    var tongTien = i.toString()
    var donHang = new DonHang();

    console.log(this.idDH);
    donHang.id = this.idDH;
    console.log(this.taiKhoanService.taikhoan.idTK);
    donHang.idTK = this.taiKhoanService.taikhoan.idTK;
    console.log(this.hovaten.value);
    donHang.hoVaTen = this.hovaten.value;
    console.log(this.diachi.value);
    donHang.diaChi = this.diachi.value;
    console.log(this.sdt.value);
    donHang.sdt = this.sdt.value;
    console.log(this.tencard.value);
    donHang.tenCard = this.tencard.value;
    console.log(this.socard.value);
    donHang.soCard = this.socard.value;
    console.log(this.cvv.value);
    donHang.cvv = this.cvv.value;
    console.log(tongTien);
    donHang.tongTien = tongTien;
    console.log(ngayLap);
    donHang.ngayLap = ngayLap;
    donHang.trangThai = 1;

    this.taoChiTietDonHang(this.idDH);

    this.donHangService.taoDonHang(donHang).subscribe();

    this.router.navigate(['']);
  }

  private taoChiTietDonHang(idDH: string) {
    this.items.forEach(item => {
      var ctdh = new ChiTietDonHang();
      this.sanPhamService.getProduct(item.idSP).subscribe(
        (result: Qlsanpham) => {
          var soLuong = Number.parseInt(result.soluong) - item.soLuong;
          result.soluong = soLuong.toString();
          this.sanPhamService.capNhatSanPham(result).subscribe();
          this.gioHangService.xoaGioHang(item.id).subscribe();
        }
      );

      ctdh.idDH = idDH;
      ctdh.tenSP = item.tenSP;
      ctdh.gia = item.gia;
      ctdh.soLuong = item.soLuong

      this.chiTietDonHangService.themChiTietDonHang(ctdh).subscribe();
    });
  }

}
