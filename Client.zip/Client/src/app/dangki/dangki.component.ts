import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { TaiKhoan } from '../models/tai-khoan.model';
import { QltaikhoanService } from '../qlcomponent/shared/qltaikhoan.service';

@Component({
  selector: 'app-dangki',
  templateUrl: './dangki.component.html',
  styleUrls: ['./dangki.component.css']
})
export class DangkiComponent implements OnInit {

  constructor(public service : QltaikhoanService,
    private toastr:ToastrService) { }

  ngOnInit(): void {
  }

  onSubmit(form:NgForm){
    this.register(form);
  }

  register(form:NgForm){
    this.service.postTaiKhoan().subscribe(
      res =>{
        this.resetForm(form);
        this.service.refreshList();
        this.toastr.success('Registered successfully', 'Đăng kí thành công');
      },
      err =>{console.log(err)}
    );
  }

  resetForm(form:NgForm){ 
    form.form.reset();
    this.service.formData = new TaiKhoan();
  }
}
